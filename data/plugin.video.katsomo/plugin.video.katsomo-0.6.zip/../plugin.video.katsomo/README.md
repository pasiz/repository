plugin.video.katsomo
============

rewrite of plugin.video.katsomo

featuring xbmcswift (can be debugged commandline in virtual environment), caching and more structured

To install download [zip file](https://github.com/pasiz/plugin.video.katsomo/archive/master.zip)
and install it via xbmc -> addons -> install from zip file
