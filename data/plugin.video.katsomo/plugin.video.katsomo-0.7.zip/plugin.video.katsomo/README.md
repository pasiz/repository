plugin.video.katsomo
============

rewrite of plugin.video.katsomo

featuring xbmcswift (can be debugged commandline in virtual environment), caching and more structured

To install download [zip file](https://github.com/pasiz/plugin.video.katsomo/archive/master.zip)
and install it via xbmc -> settings -> addons -> install from zip file

Alternatively you can download [repository file](https://github.com/pasiz/repository/tree/master/data/repository.fiplugins) 
and install it via xbmc -> settings -> addons -> install from zip file

then install plugins from repository
